import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { LoginService } from '../service/login.service';
import { Login } from '../../model/login';

@Component({
  selector: 'app-login-list',
  templateUrl: './login-list.component.html',
  styleUrls: ['./login-list.component.css']
})
export class LoginListComponent implements OnInit {

  changepassword: FormGroup;
  loginList: Login[];

  constructor(private fb: FormBuilder,private loginservice:LoginService) { }

  ngOnInit() {
    this.changepassword = this.fb.group({
      loginId: [, Validators.required],
      username: [, Validators.required],
      password: [, Validators.required]
    });
    this.loginservice.getLogin().subscribe((data:Login[])=>this.loginList=data);
  }

  onAddClick() {
    this.loginservice.updateLogin(this.changepassword.value.loginId,this.changepassword.value).subscribe(
      data => console.log(data)
    );
  }

}
