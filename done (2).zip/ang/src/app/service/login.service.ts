import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Login } from '../../model/login';

@Injectable({
  providedIn: 'root'
})
export class LoginService {


  url: string = 'http://localhost:8090';

  constructor(private http: HttpClient) { }

  updateLogin(id:number,login: Login) {
    return this.http.put<Login>(this.url+"/changepassword/"+id,login);
  }

  getLogin() {
    return this.http.get<Login[]>(this.url+"/get");
  }
}

