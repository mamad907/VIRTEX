export class Login {
    loginId?: number;
    password?: string;
    username?: string;
}